'use strict';
/* ================= Пиксель-тамагочи: логика + спрайт (v2: тело, потребности, хотелки) ================= */

/* ---------- время (в макете можно ускорять) ---------- */
const CLOCK = { speed: 1, base: Date.now(), realBase: Date.now() };
const now = () => CLOCK.base + (Date.now() - CLOCK.realBase) * CLOCK.speed;
function setSpeed(s) { CLOCK.base = now(); CLOCK.realBase = Date.now(); CLOCK.speed = s; }
const HOUR = 3600e3;

/* ---------- правила ---------- */
const RULES = {
  energy: { awake: 4, sleep: 12.5 },   // в час
  food: 6,                              // сытость −6/ч (≈16 ч до нуля)
  water: 8,                             // вода −8/ч (≈12 ч)
  sleepMul: 0.35,                       // во сне голод/жажда растут медленнее
  nightMul: 2,                          // ночью бодрствование утомляет вдвое быстрее
  low: 30,                              // ниже — «хочет»
  deathAfter: 12,                       // часов, когда хоть одна потребность на нуле → выгорела
  eat: 35, drink: 40,
  xpFullSleep: 12, xpShortSleep: 4, xpNeed: 2, xpWish: 4, xpPet: 1, petCap: 15, xpDay: 6,
  wishEvery: [1.5, 4],                  // хотелки появляются раз в 1.5–4 часа
  wishLasts: 1,                         // и ждут 1 час
};
const xpNeed = lvl => 40 + lvl * 30;
const VITALS = ['energy', 'food', 'water'];
const WISHES = { smoke: ['🚬', 'Перекур'], music: ['🎧', 'Музыка'], coffee: ['☕', 'Кофе'], dance: ['💃', 'Потанцевать'], walk: ['🚶', 'Погулять'] };
const NEED_ICON = { energy: '😴', food: '🍔', water: '🥤' };
const NEED_TXT = { energy: 'Хочет спать', food: 'Хочет есть', water: 'Хочет пить' };

const ITEMS = [
  { id: 'gl_black', slot: 'glasses', lvl: 2, n: 'Чёрные очки' },
  { id: 'phones', slot: 'phones', lvl: 3, n: 'Наушники' },
  { id: 'hair_pink', slot: 'hair', lvl: 4, n: 'Розовые волосы' },
  { id: 'ears_cat', slot: 'head', lvl: 5, n: 'Кошачьи ушки' },
  { id: 'shirt_red', slot: 'shirt', lvl: 6, n: 'Красная толстовка' },
  { id: 'skirt', slot: 'legs', lvl: 6, n: 'Клетчатая юбка' },
  { id: 'hat_ush', slot: 'head', lvl: 7, n: 'Ушанка' },
  { id: 'gl_gold', slot: 'glasses', lvl: 8, n: 'Золотые очки' },
  { id: 'hair_white', slot: 'hair', lvl: 9, n: 'Белые волосы' },
  { id: 'shirt_black', slot: 'shirt', lvl: 9, n: 'Чёрная толстовка' },
  { id: 'boots', slot: 'shoes', lvl: 9, n: 'Красные кеды' },
  { id: 'crown', slot: 'head', lvl: 10, n: 'Корона' },
  { id: 'gl_none', slot: 'glasses', lvl: 12, n: 'Линзы (без очков)' },
];
const SLOTS = { glasses: 'Очки', hair: 'Волосы', head: 'Голова', phones: 'Уши', shirt: 'Верх', legs: 'Низ', shoes: 'Обувь' };

/* ---------- состояние ---------- */
const STORE_KEY = 'pixelpet.v2';
const EXTRA = { stepsDay: '', stepsXp: 0 };
function freshState(record) {
  const t = now();
  return { born: t, lastTick: t, lvl: 1, xp: 0, energy: 80, food: 70, water: 70, asleep: false, sleepStart: 0,
    zeroSince: 0, dead: false, deadAt: 0, eq: {}, record: record || 0, petDay: '', petCount: 0,
    lastDay: Math.floor(t / 864e5), wish: null, nextWish: t + 0.5 * HOUR };
}
let S = (() => { try { return Object.assign(freshState(), JSON.parse(localStorage.getItem(STORE_KEY)) || {}); } catch (e) { return freshState(); } })();
const save = () => { try { localStorage.setItem(STORE_KEY, JSON.stringify(S)); } catch (e) {} };

const ageDays = () => Math.floor(((S.dead ? S.deadAt : now()) - S.born) / 864e5);
const unlocked = it => S.lvl >= it.lvl;
const minVital = () => Math.min(S.energy, S.food, S.water);
function status() {
  if (S.dead) return 'dead';
  if (S.asleep) return 'sleep';
  if (minVital() <= 0) return 'faint';
  return 'awake';
}
/* самая срочная хотелка: сначала жизненные потребности, потом прихоти */
function topWant() {
  if (S.dead || S.asleep) return null;
  const low = VITALS.filter(v => S[v] < RULES.low).sort((a, b) => S[a] - S[b]);
  if (low.length) return { kind: 'need', id: low[0], icon: NEED_ICON[low[0]] };
  if (S.wish && S.wish.until > now()) return { kind: 'wish', id: S.wish.id, icon: WISHES[S.wish.id][0] };
  return null;
}
const STATUS_TXT = { awake: 'Бодрствует', faint: 'Без сил!', sleep: 'Спит', dead: 'Выгорела' };

const EV = {}; const onPet = (e, f) => (EV[e] = EV[e] || []).push(f);
const emitPet = (e, ...a) => (EV[e] || []).forEach(f => { try { f(...a); } catch (x) { console.error(x); } });

function addXp(n, why) {
  if (S.dead || n <= 0) return;
  S.xp += n;
  while (S.xp >= xpNeed(S.lvl)) { S.xp -= xpNeed(S.lvl); S.lvl++; emitPet('levelup', S.lvl, ITEMS.filter(i => i.lvl === S.lvl)); }
  emitPet('xp', n, why);
}
const rnd = (a, b) => a + Math.random() * (b - a);

/* продвигаем мир до «сейчас» шагами по 10 минут (учитываем ночь, сон и таймер выгорания) */
function tick() {
  if (S.dead) return;
  const t = now(); let cur = S.lastTick;
  while (cur < t) {
    const step = Math.min(t - cur, 10 * 60e3), h = step / HOUR, hour = new Date(cur).getHours();
    const hungerMul = S.asleep ? RULES.sleepMul : 1;
    S.food = Math.max(0, S.food - RULES.food * hungerMul * h);
    S.water = Math.max(0, S.water - RULES.water * hungerMul * h);
    if (S.asleep) {
      S.energy = Math.min(100, S.energy + RULES.energy.sleep * (window.CHARGING ? 1.4 : 1) * h);
      if (S.energy >= 100) wake(true, cur + step);
    } else {
      S.energy = Math.max(0, S.energy - RULES.energy.awake * (hour < 6 ? RULES.nightMul : 1) * h);
    }
    if (minVital() <= 0) {
      if (!S.zeroSince) { S.zeroSince = cur + step; emitPet('faint'); }
      if (cur + step - S.zeroSince >= RULES.deathAfter * HOUR) { die(cur + step); return; }
    } else S.zeroSince = 0;
    // прихоти
    if (!S.asleep && (!S.wish || S.wish.until < cur) && cur >= S.nextWish) {
      const id = pick_(Object.keys(WISHES));
      S.wish = { id, until: cur + RULES.wishLasts * HOUR };
      S.nextWish = cur + rnd(...RULES.wishEvery) * HOUR;
      emitPet('wish', id);
    }
    cur += step;
    const day = Math.floor(cur / 864e5);
    if (day > S.lastDay) { S.lastDay = day; addXp(RULES.xpDay, 'новый день'); emitPet('newday', ageDays()); }
  }
  S.lastTick = t; save();
}
const pick_ = a => a[Math.floor(Math.random() * a.length)];

/* ---------- действия ---------- */
function sleep() { if (S.dead || S.asleep) return false; S.asleep = true; S.sleepStart = now(); save(); emitPet('sleep'); return true; }
function wake(natural, at) {
  if (!S.asleep) return;
  const t = at || now(), slept = (t - S.sleepStart) / HOUR;
  S.asleep = false; S.lastTick = Math.max(S.lastTick, t);
  if (S.energy >= 100) addXp(RULES.xpFullSleep, 'выспалась'); else if (slept >= 3) addXp(RULES.xpShortSleep, 'поспала');
  emitPet('wake', { natural, slept, energy: S.energy }); save();
}
/* поесть / попить: false — если не хочет */
function feed(kind) {
  if (S.dead || S.asleep) return 'no';
  const key = kind === 'eat' ? 'food' : 'water', add = kind === 'eat' ? RULES.eat : RULES.drink;
  if (S[key] > 90) return 'full';
  const wasLow = S[key] < 60;
  S[key] = Math.min(100, S[key] + add);
  if (wasLow) addXp(RULES.xpNeed, kind);
  save(); return 'ok';
}
/* исполнить прихоть (перекур, музыка…) */
function fulfill(id) {
  if (S.wish && S.wish.id === id && S.wish.until > now()) { S.wish = null; addXp(RULES.xpWish, 'прихоть'); save(); return true; }
  return false;
}
function pet() {
  if (S.dead) return 0;
  const d = new Date(now()).toDateString();
  if (S.petDay !== d) { S.petDay = d; S.petCount = 0; }
  if (S.petCount < RULES.petCap) { S.petCount++; addXp(RULES.xpPet, 'погладили'); save(); return 1; }
  save(); return 0;
}
function die(at) { S.dead = true; S.deadAt = at || now(); S.asleep = false; S.record = Math.max(S.record || 0, ageDays()); save(); emitPet('dead'); }
function restart() { const r = Math.max(S.record || 0, ageDays()); S = freshState(r); save(); emitPet('restart'); }
function equip(slot, id) { if (id) S.eq[slot] = id; else delete S.eq[slot]; save(); emitPet('equip'); }

/* ================= СПРАЙТ: голова + тело ================= */
const HEAD = [
  ".....hhhhhh.....",
  "...hhhhhhhhhh...",
  "..hhhhhhhhhhhh..",
  ".hhhhhhhhhhhhhh.",
  ".hhhhhhhhhhhhhh.",
  "hhhhhshhhhshhhhh",
  "hhhssssshssssshh",
  "hhsssssssssssshh",
  "hhgggggssggggghh",
  "hhgLLLggggLLLghh",
  "hhgLLLgssgLLLghh",
  "hhgggggssggggghh",
  "hhbssssssssssbhh",
  ".hhssssmmsssshh.",
  ".hh.ssssssss.hh.",
  ".hh..cwwwwc..hh.",
];
const BODY = [
  "..cccccccccccc..",
  ".cccccccccccccc.",
  ".cccccccccccccc.",
  ".cc.cccccccc.cc.",
  ".cc.cccccccc.cc.",
  ".ss.cccccccc.ss.",
  "....dddddddd....",
  "...dddddddddd...",
];
const LEGS = {
  stand: ["....ss....ss....", "....ss....ss....", "....ss....ss....", "...kkk....kkk..."],
  walk1: ["....ss....ss....", "...ss......ss...", "..ss........ss..", ".kkk........kkk."],
  walk2: ["....ss....ss....", ".....ss..ss.....", ".....ss..ss.....", "....kkk..kkk...."],
};
const TOP = 3; // запас под ушки/ушанку/корону
const BASEPAL = { h: "#4b2c8f", s: "#ffd9b8", g: "#b3122e", L: "#eaf2ff", b: "#ff8fab", B: "#ff4d4d", m: "#c2365a",
  c: "#1d2a78", d: "#2b2b3a", w: "#ffffff", p: "#1b1440", H: "#222222", E: "#2b2b2b", R: "#e0245e", W: "#f4f1ea", F: "#d98a3a",
  O: "#ff6a00", Y: "#ffd23f", K: "#6b4a2b", k: "#3a2a1e", q: "#8a6a45", P: "#ff9ec7", x: "#b3122e" };
const LOOK = { dir: 0, blink: false, eyes: 'open', mouth: 'normal', cig: false, phones: false, legs: 'stand', armUp: false, hat: null };

function palette() {
  const p = { ...BASEPAL };
  if (S.eq.hair === 'hair_pink') p.h = '#e0569b';
  if (S.eq.hair === 'hair_white') p.h = '#dcdce6';
  if (S.eq.glasses === 'gl_black') p.g = '#1a1a1a';
  if (S.eq.glasses === 'gl_gold') p.g = '#d4a017';
  if (S.eq.shirt === 'shirt_red') p.c = '#b3122e';
  if (S.eq.shirt === 'shirt_black') p.c = '#202020';
  if (S.eq.shoes === 'boots') p.k = '#c8102e';
  return p;
}
function grid() {
  const g = [];
  for (let i = 0; i < TOP; i++) g.push([...'................']);
  HEAD.forEach(r => g.push([...r])); BODY.forEach(r => g.push([...r])); LEGS[LOOK.legs].forEach(r => g.push([...r]));
  const Y = y => y + TOP, set = (x, y, ch) => { if (g[Y(y)] && x >= 0 && x < 16) g[Y(y)][x] = ch; };
  const st = status();
  const eyes = st === 'sleep' || st === 'dead' ? 'closed' : st === 'faint' ? 'x' : LOOK.blink ? 'closed' : (S.energy < RULES.low && LOOK.eyes === 'open' ? 'half' : LOOK.eyes);
  const noG = S.eq.glasses === 'gl_none';
  if (noG) for (const y of [8, 9, 10, 11]) for (let x = 2; x < 14; x++) if ('gL'.includes(g[Y(y)][x])) g[Y(y)][x] = 's';
  const lens = noG ? 's' : 'L';
  for (const x0 of [3, 10]) {
    if (eyes === 'closed') { for (let x = x0; x < x0 + 3; x++) { set(x, 9, lens); set(x, 10, 'p'); } }
    else if (eyes === 'x') { set(x0, 9, 'p'); set(x0 + 2, 9, 'p'); set(x0 + 1, 10, 'p'); set(x0, 10, lens); set(x0 + 2, 10, lens); }
    else if (eyes === 'half') { for (let x = x0; x < x0 + 3; x++) set(x, 9, 'h'); set(x0 + 1 + LOOK.dir, 10, 'p'); }
    else { set(x0 + 1 + LOOK.dir, 9, 'p'); set(x0 + 1 + LOOK.dir, 10, 'p'); }
  }
  const mouth = st === 'faint' || st === 'dead' ? 'o' : LOOK.mouth;
  if (mouth === 'smile') { set(6, 12, 'm'); set(9, 12, 'm'); set(6, 13, 's'); set(9, 13, 's'); }
  if (mouth === 'o') { set(7, 14, 'm'); set(8, 14, 'm'); }
  if (mouth === 'flat') { set(6, 13, 'm'); set(9, 13, 'm'); }
  if (mouth === 'eat') { set(7, 13, 'p'); set(8, 13, 'p'); set(7, 14, 'm'); set(8, 14, 'm'); }
  if (LOOK.cig) { set(9, 13, 'F'); set(10, 13, 'W'); set(11, 13, 'W'); set(12, 13, 'O'); }
  if (LOOK.armUp) { // правая рука поднята (машет / держит что-то у рта)
    for (let y = 19; y <= 21; y++) { set(13, y, '.'); set(14, y, '.'); }
    set(14, 18, 'c'); set(15, 17, 'c'); set(15, 16, 's'); set(15, 15, 's');
  }
  if (S.eq.legs === 'skirt') { for (const y of [22, 23]) for (let x = 2; x < 14; x++) if (g[Y(y)][x] === 'd') g[Y(y)][x] = ((x + y) % 2 ? 'x' : 'd'); set(2, 23, 'x'); set(13, 23, 'x'); }
  if (S.eq.phones === 'phones' || LOOK.phones) {
    for (let x = 3; x < 13; x++) set(x, 1, 'H'); set(2, 2, 'H'); set(13, 2, 'H');
    for (let y = 8; y < 12; y++) { set(0, y, 'E'); set(1, y, 'E'); set(14, y, 'E'); set(15, y, 'E'); }
    set(0, 9, 'R'); set(0, 10, 'R'); set(15, 9, 'R'); set(15, 10, 'R');
  }
  const head = S.eq.head || LOOK.hat;   // в мороз сама надевает ушанку, если голова свободна
  if (head === 'ears_cat') { [[2, -2], [3, -2], [2, -1], [3, -1], [4, -1], [12, -2], [13, -2], [11, -1], [12, -1], [13, -1]].forEach(([x, y]) => set(x, y, 'h')); set(3, -1, 'P'); set(12, -1, 'P'); }
  if (head === 'hat_ush') { for (let x = 2; x < 14; x++) { set(x, -2, 'K'); set(x, -1, 'K'); set(x, 0, 'q'); set(x, 1, 'q'); }
    for (let y = 2; y < 9; y++) { set(0, y, 'q'); set(1, y, 'q'); set(14, y, 'q'); set(15, y, 'q'); } set(7, -1, 'Y'); set(8, -1, 'Y'); }
  if (head === 'crown') { for (let x = 4; x < 12; x++) set(x, -1, 'Y'); [4, 7, 8, 11].forEach(x => set(x, -2, 'Y')); [4, 11].forEach(x => set(x, -3, 'Y')); set(7, -3, 'Y'); set(8, -3, 'Y'); set(7, -1, 'B'); set(8, -1, 'B'); }
  return g;
}
function spriteSVG(opts = {}) {
  let g = grid(); if (opts.headOnly) g = g.slice(0, TOP + 16);
  const P = palette(); let r = '';
  g.forEach((row, y) => row.forEach((ch, x) => { if (P[ch]) r += `<rect x="${x}" y="${y}" width="1.03" height="1.03" fill="${P[ch]}"/>`; }));
  return `<svg viewBox="0 0 16 ${g.length}" shape-rendering="crispEdges">${r}</svg>`;
}
