'use strict';
/* ================= Пиксель-тамагочи: интерфейс, движение, реакции (v3) =================
   Координаты «мира» = координаты экрана телефона (в dp). В приложении страница — это маленькое
   прозрачное окно поверх других приложений, которое ездит за Пикселем (см. syncWindow). */
const $ = s => document.querySelector(s);
const pick = a => a[Math.floor(Math.random() * a.length)];
const NATIVE = !!window.PetNative;
const N = (fn, ...a) => { try { return NATIVE ? PetNative[fn](...a) : undefined; } catch (e) { return undefined; } };
const world = $('#world'), petEl = $('#pet'), spr = $('#spr'), fx = $('#fx'), bubble = $('#bubble'),
  menuEl = $('#menu'), card = $('#card'), wishEl = $('#wish'), dlg = $('#dlg');
const PW = 56, SCALE = PW / 16, PH = () => (TOP + HEAD.length + BODY.length + 4) * SCALE;

/* ---------- экран и пол ---------- */
let SCREEN = { w: innerWidth, h: innerHeight, top: 0, bottom: 0 }, FLOOR_UP = NATIVE ? 150 : 64;
function readScreen() {
  if (NATIVE) { try { SCREEN = JSON.parse(PetNative.screen()); FLOOR_UP = +PetNative.floor() || 0; } catch (e) {} }
  else SCREEN = { w: innerWidth, h: innerHeight, top: 0, bottom: 0 };
  world.style.width = SCREEN.w + 'px'; world.style.height = SCREEN.h + 'px';
}
const floorY = () => SCREEN.h - SCREEN.bottom - FLOOR_UP - PH();
const petRect = () => ({ left: POS.x, top: POS.y, right: POS.x + PW, bottom: POS.y + PH(), width: PW, height: PH() });

/* ---------- окно-оверлей ---------- */
let WIN = { x: 0, y: 0, w: 0, h: 0 }, fullWin = false;
function rectOf(el) { return { l: el.offsetLeft, t: el.offsetTop, r: el.offsetLeft + el.offsetWidth, b: el.offsetTop + el.offsetHeight }; }
function syncWindow() {
  if (!NATIVE) return;
  let x, y, w, h;
  if (fullWin || dlg.classList.contains('show')) { x = 0; y = 0; w = SCREEN.w; h = SCREEN.h; }
  else {
    const lying = petEl.classList.contains('lying');
    let l = POS.x - (lying ? PH() - PW / 2 + 10 : 30), t = POS.y - 70, r = POS.x + PW + 50, b = POS.y + PH() + 6;
    for (const el of [bubble, menuEl, card]) if (el.classList.contains('show')) { const q = rectOf(el); l = Math.min(l, q.l - 4); t = Math.min(t, q.t - 4); r = Math.max(r, q.r + 6); b = Math.max(b, q.b + 6); }
    x = Math.max(0, Math.floor(l)); y = Math.max(0, Math.floor(t)); w = Math.min(SCREEN.w, Math.ceil(r)) - x; h = Math.min(SCREEN.h, Math.ceil(b)) - y;
  }
  if (x === WIN.x && y === WIN.y && w === WIN.w && h === WIN.h) return;
  WIN = { x, y, w, h };
  world.style.transform = `translate(${-x}px, ${-y}px)`;
  PetNative.setWindow(x, y, w, h);
}

/* ---------- позиция и движение ---------- */
const POS = { x: 0, y: 0, vy: 0, face: 1 };
let mode = 'idle', walkTo = null, walkSpeed = 40, legT = 0, hidden = false, rafOn = false;
function place() {
  petEl.style.transform = `translate(${POS.x}px, ${POS.y}px)`;
  spr.classList.toggle('left', POS.face < 0);
  if (bubble.classList.contains('show')) placeBubble();
  if (menuEl.classList.contains('show')) placeMenu();
  syncWindow();
}
try { const p = JSON.parse(localStorage.getItem('pixelpet.x')); if (typeof p === 'number') POS.x = p; } catch (e) {}
function initPos() { POS.x = Math.max(0, Math.min(SCREEN.w - PW, POS.x || SCREEN.w - PW - 20)); POS.y = floorY(); place(); }
const saveX = () => { try { localStorage.setItem('pixelpet.x', JSON.stringify(POS.x)); } catch (e) {} };

/* анимационный цикл крутится только пока она идёт или падает — бережём батарею */
function kick() { if (!rafOn) { rafOn = true; lastT = performance.now(); requestAnimationFrame(frame); } }
let lastT = 0;
function frame(t) {
  const dt = Math.min(0.05, (t - lastT) / 1000); lastT = t;
  if (mode === 'fall') {
    POS.vy += 1800 * dt; POS.y += POS.vy * dt;
    if (POS.y >= floorY()) { const hard = POS.vy > 900; POS.y = floorY(); POS.vy = 0; mode = 'idle'; land(hard); }
    place();
  } else if (mode === 'walk' && walkTo !== null) {
    const d = walkTo - POS.x, stepPx = walkSpeed * dt;
    POS.face = d < 0 ? -1 : 1;
    if (Math.abs(d) <= stepPx) { POS.x = walkTo; walkTo = null; mode = 'idle'; LOOK.legs = 'stand'; draw(); saveX(); }
    else { POS.x += Math.sign(d) * stepPx; legT += dt; const legs = Math.floor(legT / 0.18) % 2 ? 'walk1' : 'walk2'; if (legs !== LOOK.legs) { LOOK.legs = legs; draw(); } }
    place();
  }
  if (mode === 'walk' || mode === 'fall') requestAnimationFrame(frame); else rafOn = false;
}
function goTo(x, speed = 40) {
  if (status() !== 'awake' || hidden) return;
  walkTo = Math.max(0, Math.min(SCREEN.w - PW, x)); walkSpeed = S.energy < RULES.low ? speed * 0.5 : speed; mode = 'walk'; legT = 0; kick();
}
function fall() { mode = 'fall'; kick(); }
function land(hard) {
  if (hard && status() === 'awake') { stopAnim(); LOOK.eyes = 'x'; draw(); spawn('stars', '✦ ✧ ✦', 8, -8, 1400); say(pick(['Ай! 😵', 'Голова кружится…', 'Не бросай меня так!'])); later(end, 1500); }
}

/* ---------- отрисовка ---------- */
function draw() {
  spr.innerHTML = spriteSVG();
  const st = status();
  petEl.classList.toggle('dead', st === 'dead');
  petEl.classList.toggle('lying', st === 'sleep' || st === 'faint' || st === 'dead');
  const w = topWant();
  wishEl.classList.toggle('show', !!w && !hidden);
  if (w) { wishEl.innerHTML = `<span>${w.icon}</span>`; wishEl.dataset.kind = w.kind; wishEl.dataset.id = w.id; }
  if (card.classList.contains('show') && $('#cTitle').textContent === 'Статус') renderStatus();
}
let bubT = null;
function say(t, ms) {
  if (hidden || !t) return;
  bubble.textContent = t; bubble.classList.add('show'); placeBubble(); syncWindow();
  clearTimeout(bubT); bubT = setTimeout(() => { bubble.classList.remove('show'); syncWindow(); }, ms || Math.max(2400, t.length * 60));
}
function placeBubble() {
  const r = petRect(), W = SCREEN.w;
  bubble.style.maxWidth = Math.min(210, W - 16) + 'px';
  const bw = bubble.offsetWidth, bh = bubble.offsetHeight;
  let left = r.left + r.width / 2 - bw / 2; left = Math.max(8, Math.min(W - bw - 8, left));
  const top = r.top - bh - 58, below = top < SCREEN.top + 4;
  bubble.style.left = left + 'px'; bubble.style.top = (below ? r.bottom + 8 : top) + 'px';
  bubble.classList.toggle('below', below);
  bubble.style.setProperty('--tail', Math.max(8, Math.min(bw - 18, r.left + r.width / 2 - left - 6)) + 'px');
}
function spawn(cls, html, x, y, life = 1800) {
  const d = document.createElement('div'); d.className = 'p ' + cls; d.innerHTML = html || '';
  d.style.left = x + 'px'; d.style.top = y + 'px'; fx.appendChild(d); if (life) setTimeout(() => d.remove(), life); return d;
}
const HAND = () => ({ x: POS.face > 0 ? PW - 6 : -10, y: 13 * SCALE });

/* ---------- фразы ---------- */
const T = {
  hello: ['Йо. Я тут, если что', 'О, привет! 🙂', 'Я на месте. Работай, я присмотрю'],
  morning: ['Доброе утро… кофе был?', 'Утро. Не люблю утро'],
  night: ['Уже ночь. Уложи меня, а? 🌙', 'Ночью я устаю вдвое быстрее, между прочим'],
  idle: ['Жизнь — как Windows 98: главное не трогать, если работает', 'Я не ленюсь, я в режиме энергосбережения', 'Вайб сегодня: 256 цветов',
    'Сейчас бы на дискету и в 1998…', 'Не спеши. Всё успеется', 'Сижу. Смотрю. Одобряю', 'Эх, модем бы сейчас послушать', 'Хожу-брожу по экрану'],
  need: { energy: ['Я бы вздремнула… 🥱', 'Глаза слипаются'], food: ['Есть хочу 🍔', 'В животе урчит…'], water: ['Пить хочется 🥤', 'Во рту пустыня'] },
  wish: { smoke: 'Хочу перекурить 🚬', music: 'Хочу музыку послушать 🎧', coffee: 'Кофейку бы ☕', dance: 'Давай потанцуем? 💃', walk: 'Пойдём погуляем? 🚶' },
  faint: ['Без сил… 😵', 'Я… всё… не могу…'],
  sleepTalk: ['*сопит*', 'Zzz… ещё пять минуточек…', '*бормочет про дискеты*'],
  wakeGood: ['Выспалась! ✨', 'Доброе! Я полна сил'], wakeBad: ['Эй! Я не доспала 😾', 'Зачем разбудил?.. Ладно'],
  pet: ['Хи 😊', 'Мурр', 'Ещё!', 'Приятно 💛'], petMax: ['Всё, хватит, я не кошка 😅'],
  full: { eat: 'Не, я сыта', drink: 'Не хочу пить' },
};
const hourNow = () => new Date(now()).getHours();
const plural = (n, a, b, c) => { const m = n % 10, h = n % 100; return m === 1 && h !== 11 ? a : m >= 2 && m <= 4 && (h < 10 || h >= 20) ? b : c; };

/* ---------- анимации-действия ---------- */
let anim = null, animT = [], nextAnim = Date.now() + 5000;
const later = (f, ms) => animT.push(setTimeout(f, ms));
function stopAnim() {
  animT.forEach(clearTimeout); animT = []; if (anim && anim.iv) clearInterval(anim.iv); anim = null;
  Object.assign(LOOK, { eyes: 'open', mouth: 'normal', cig: false, phones: false, dir: 0, armUp: false });
  if (mode === 'act') mode = 'idle';
  petEl.classList.remove('bob', 'dance'); draw();
}
const ACTS = {
  smoke() { LOOK.cig = true; LOOK.eyes = 'half'; draw(); later(() => say(pick(['Перекур. Никуда не спешим', '*пфф* …хорошо сидим'])), 500);
    anim.iv = setInterval(() => spawn('puff', '', POS.face > 0 ? 46 : 2, 46, 2400), 650);
    later(() => { LOOK.cig = false; LOOK.mouth = 'o'; draw(); }, 8000); later(end, 9500); },
  music(title) { LOOK.phones = true; LOOK.eyes = 'closed'; LOOK.mouth = 'smile'; draw(); petEl.classList.add('bob');
    later(() => say(title ? `♪ ${title}` : pick(['♪ Мой трек, не мешай', 'Лоу-фай для отдыха'])), 400);
    anim.iv = setInterval(() => spawn('mnote', pick(['♪', '♫', '♬']), Math.random() < .5 ? -10 : PW, 20, 2000), 600); later(end, title ? 12000 : 8000); },
  dance() { LOOK.mouth = 'smile'; petEl.classList.add('dance'); say('💃 Оп-оп!');
    let i = 0; anim.iv = setInterval(() => { LOOK.legs = i++ % 2 ? 'walk1' : 'walk2'; LOOK.armUp = i % 4 < 2; POS.face *= -1; place(); draw(); }, 280);
    later(() => { LOOK.legs = 'stand'; end(); }, 6000); },
  coffee() { LOOK.armUp = true; draw(); const h = HAND(); spawn('item', '☕', h.x, h.y - 30, 3500); later(() => { LOOK.eyes = 'closed'; LOOK.mouth = 'smile'; draw(); say('Кофе — топливо для пикселей ☕'); }, 800); later(end, 3600); },
  eat() { LOOK.armUp = true; draw(); const h = HAND(); spawn('item', pick(['🍔', '🍕', '🍜', '🍙']), h.x, h.y - 30, 3000);
    let i = 0; anim.iv = setInterval(() => { LOOK.mouth = i++ % 2 ? 'eat' : 'normal'; draw(); }, 250); later(() => say('Ням! 😋'), 900); later(end, 3000); },
  drink(txt) { LOOK.armUp = true; draw(); const h = HAND(); spawn('item', '🥤', h.x, h.y - 30, 2600); later(() => { LOOK.eyes = 'closed'; draw(); say(txt || 'Буль-буль… Хорошо!'); }, 700); later(end, 2600); },
  walk() { say('Погуляли! 🚶', 1500); end(); goTo(POS.x < SCREEN.w / 2 ? SCREEN.w - PW - 10 : 10, 70); },
  wave(txt) { if (txt) say(txt); let i = 0; anim.iv = setInterval(() => { LOOK.armUp = i++ % 2 === 0; draw(); }, 300); later(end, 2200); },
  watch(txt) { LOOK.dir = 0; draw(); spawn('item', '🍿', HAND().x, HAND().y - 26, 5000); say(txt); later(end, 5000); },
  cheer(txt) { LOOK.mouth = 'smile'; let i = 0; anim.iv = setInterval(() => { LOOK.armUp = i++ % 2 === 0; draw(); }, 220); say(txt); later(end, 2500); },
  glint() { spawn('glint', '✦', 40, 34, 900); later(() => spawn('glint', '✦', 10, 34, 900), 250); say('*поправляет очки*'); later(end, 1400); },
  look() { [-1, 1, -1, 0].forEach((d, i) => later(() => { LOOK.dir = d; draw(); }, i * 600)); later(end, 2600); },
  talk() { say(pick(T.idle)); later(end, 300); },
};
function act(name, arg) { if (status() !== 'awake' && !['wave'].includes(name)) return; stopAnim(); walkTo = null; LOOK.legs = 'stand'; mode = 'act'; anim = { name }; ACTS[name](arg); }
function end() { stopAnim(); nextAnim = Date.now() + 7000 + Math.random() * 8000; }

/* ---------- жизненный цикл ---------- */
let lastStatus = null, lastWant = null, lastWantSay = 0;
function loop() {
  tick();
  const st = status();
  if (st !== lastStatus) { stopAnim(); walkTo = null; if (mode === 'walk') mode = 'idle'; LOOK.legs = 'stand'; draw(); place();
    if (lastStatus && st === 'faint') say('Всё… я без сил 😵 Через 12 часов я выгорю', 5000); lastStatus = st; }
  const w = topWant(), wk = w ? w.kind + w.id : null;
  if (wk !== lastWant) { draw(); if (w && Date.now() - lastWantSay > 20000) { lastWantSay = Date.now(); say(w.kind === 'need' ? pick(T.need[w.id]) : T.wish[w.id]); } lastWant = wk; }
  if (mode === 'idle' && Math.abs(POS.y - floorY()) > 2) fall();
  if (st === 'sleep') { if (Math.random() < .45) spawn('zzz', pick(['z', 'Z']), PW - 4, 0, 2200); if (Math.random() < .03) say(pick(T.sleepTalk)); }
  else if (st === 'faint') { if (Math.random() < .06) spawn('sweat', '💧', PW - 8, 4, 1400); if (Math.random() < .03) say(pick(T.faint)); }
  else if (st === 'awake' && mode === 'idle' && !anim && Date.now() > nextAnim && !hidden && !menuEl.classList.contains('show')) {
    if (Math.random() < .45) { goTo(Math.random() * (SCREEN.w - PW)); nextAnim = Date.now() + 6000 + Math.random() * 6000; }
    else act(pick(['talk', 'talk', 'glint', 'look', 'wave', ...(S.energy < RULES.low ? [] : ['dance'])]));
  }
  sysLoop();
}
(function blink() { if (status() === 'awake' && LOOK.eyes === 'open' && !document.hidden) { LOOK.blink = true; draw(); setTimeout(() => { LOOK.blink = false; draw(); }, 130); } setTimeout(blink, 2500 + Math.random() * 3000); })();

onPet('levelup', (l, got) => { draw(); say(`Уровень ${l}! 🎉`, 3000); spawn('stars', '⭐', 18, -10, 1600);
  showCard('Новый уровень!', `<div class="lv">Уровень <b>${l}</b></div>${got.length ? '<div class="small">В гардеробе:<br>' + got.map(i => '• ' + i.n).join('<br>') + '</div><div class="cbtns"><div class="btn out" data-m="wardrobe">👕 Примерить</div></div>' : ''}`); });
onPet('wake', w => { stopAnim(); draw(); place(); say(w.natural || w.energy >= 90 ? pick(T.wakeGood) : pick(T.wakeBad)); });
onPet('sleep', () => { stopAnim(); draw(); place(); say('Спокойной ночи 🌙', 1800); });
onPet('dead', () => { stopAnim(); draw(); place(); say('Я… выгорела. Прости 🥀', 5000); showDead(); });
onPet('restart', () => { stopAnim(); closeCard(); initPos(); draw(); say('Привет… Я — Пиксель. Позаботишься обо мне? 🙂', 4000); });
onPet('newday', d => say(`Мы вместе уже ${d} ${plural(d, 'день', 'дня', 'дней')}! 🎈`));

/* ---------- касания: тап — погладить, тащить — перенести ---------- */
let drag = null;
const wx = e => e.clientX + WIN.x, wy = e => e.clientY + WIN.y;
spr.addEventListener('pointerdown', e => {
  drag = { x: wx(e), y: wy(e), px: POS.x, py: POS.y, moved: false, ly: wy(e), lt: performance.now(), vy: 0 };
  spr.setPointerCapture(e.pointerId);
});
spr.addEventListener('pointermove', e => {
  if (!drag) return;
  const dx = wx(e) - drag.x, dy = wy(e) - drag.y;
  if (!drag.moved && Math.hypot(dx, dy) < 8) return;
  if (!drag.moved) { drag.moved = true; stopAnim(); walkTo = null; mode = 'drag'; LOOK.legs = 'walk1'; LOOK.mouth = 'o'; draw(); bubble.classList.remove('show'); closeMenu(); closeCard(); fullWin = true; syncWindow(); }
  const t = performance.now(); drag.vy = (wy(e) - drag.ly) / Math.max(1, t - drag.lt) * 1000; drag.ly = wy(e); drag.lt = t;
  POS.x = Math.max(-10, Math.min(SCREEN.w - PW + 10, drag.px + dx)); POS.y = Math.max(SCREEN.top, Math.min(floorY(), drag.py + dy));
  place();
});
function endDrag() {
  if (!drag) return;
  const d = drag; drag = null;
  if (d.moved) { fullWin = false; LOOK.legs = 'stand'; LOOK.mouth = 'normal'; POS.vy = Math.max(0, d.vy * 0.5); saveX(); draw(); fall(); return; }
  doPet();
}
spr.addEventListener('pointerup', endDrag);
spr.addEventListener('pointercancel', () => { if (drag && drag.moved) endDrag(); drag = null; fullWin = false; syncWindow(); });
function doPet() {
  if (status() !== 'awake') { if (status() === 'sleep') say('*сопит* …не буди', 1500); return; }
  const ok = pet(); stopAnim(); mode = 'act'; LOOK.mouth = 'smile'; LOOK.eyes = 'closed'; draw();
  spawn('heart', '💛', PW / 2 - 8, -6, 1600); say(ok ? pick(T.pet) : pick(T.petMax)); later(end, 1400);
}

/* ---------- меню «⋯» из блоков ---------- */
$('#dots').addEventListener('click', e => { e.stopPropagation(); menuEl.classList.contains('show') ? closeMenu() : openMenu(); });
const B = (id, ic, n, dis) => `<div class="blk out ${dis ? 'dis' : ''}" data-m="${id}"><span>${ic}</span><small>${n}</small></div>`;
function openMenu() {
  closeCard();
  const st = status(), up = st === 'awake', can = st === 'awake' || st === 'faint';
  menuEl.innerHTML = st === 'dead' ? B('restart', '🔄', 'Заново') + B('status', '📊', 'Итоги') :
    (S.asleep ? B('wake', '☀', 'Разбудить') : B('sleep', '🛏', 'Спать')) + B('eat', '🍔', 'Поесть', !can) + B('drink', '🥤', 'Попить', !can) +
    B('smoke', '🚬', 'Перекур', !up) + B('music', '🎧', 'Музыка', !up) + B('dance', '💃', 'Танец', !up) +
    B('status', '📊', 'Статус') + B('wardrobe', '👕', 'Гардероб') + B('more', '⋯', 'Ещё');
  menuEl.classList.add('show'); placeMenu(); syncWindow();
}
function closeMenu() { if (!menuEl.classList.contains('show')) return; menuEl.classList.remove('show'); syncWindow(); }
function sidePlace(el, dy = 0) {
  const r = petRect(), mw = el.offsetWidth, mh = el.offsetHeight;
  const right = r.right + 8 + mw < SCREEN.w;
  el.style.left = (right ? r.right + 8 : Math.max(4, r.left - mw - 8)) + 'px';
  el.style.top = Math.max(SCREEN.top + 4, Math.min(SCREEN.h - SCREEN.bottom - mh - 4, r.top + dy)) + 'px';
}
const placeMenu = () => sidePlace(menuEl, -10);
function doAction(m) {
  closeMenu();
  const st = status();
  if (m === 'sleep') { walkTo = null; mode = 'idle'; sleep(); }
  if (m === 'wake') wake(false);
  if (m === 'eat' || m === 'drink') { const r = feed(m); if (r === 'full') say(T.full[m]); else if (r === 'ok') { if (st === 'awake') act(m); else say('Спасибо… 🥺'); } else say('Сейчас не могу…'); }
  if (['smoke', 'music', 'dance', 'coffee', 'walk'].includes(m)) { if (st !== 'awake') { say('Сил нет…'); return; } fulfill(m); act(m); }
  if (m === 'status') showStatus();
  if (m === 'wardrobe') wardrobe();
  if (m === 'more') showCard('Ещё', `<div class="grid3">${B('coffee', '☕', 'Кофе')}${B('walk', '🚶', 'Гулять')}${B('pomo', '🍅', POMO ? 'Стоп' : 'Помодоро')}
    ${B('torch', '🔦', 'Фонарик')}${B('alarm', '⏰', 'Будильник')}${B('camera', '📷', 'Камера')}${B('help', '❔', 'Правила')}${B('hide', '🙈', 'Спрятать')}${B('setup', '⚙', 'Настройки')}</div>`);
  if (m === 'pomo') pomodoro();
  if (m === 'torch') { TORCH = !TORCH; N('torch', TORCH); say(TORCH ? 'Да будет свет! 🔦' : 'Выключила'); }
  if (m === 'alarm') { N('open', 'alarm'); say('Открываю будильник ⏰'); }
  if (m === 'camera') { N('open', 'camera'); say('Я не фотогеничная, не наводи 📷'); }
  if (m === 'setup') N('open', 'setup');
  if (m === 'help') help();
  if (m === 'hide') hide(true, 60);
  if (m === 'restart') restart();
  draw(); place();
}
let TORCH = false;
menuEl.addEventListener('click', e => { const b = e.target.closest('[data-m]'); if (b && !b.classList.contains('dis')) doAction(b.dataset.m); });
card.addEventListener('click', e => {
  if (e.target.closest('[data-close]')) return closeCard();
  const b = e.target.closest('[data-m]'); if (b && !b.classList.contains('dis')) { closeCard(); doAction(b.dataset.m); }
});
wishEl.addEventListener('click', e => {
  e.stopPropagation();
  const k = wishEl.dataset.kind, id = wishEl.dataset.id;
  doAction(k === 'need' ? (id === 'energy' ? 'sleep' : id === 'food' ? 'eat' : 'drink') : id);
});
document.addEventListener('pointerdown', e => { if (!e.target.closest('#menu') && !e.target.closest('#dots') && !e.target.closest('#card')) closeMenu(); });

/* ---------- карточки ---------- */
function showCard(title, html) { $('#cTitle').textContent = title; $('#cBody').innerHTML = html; card.classList.add('show'); sidePlace(card, -20); syncWindow(); }
function closeCard() { if (!card.classList.contains('show')) return; card.classList.remove('show'); syncWindow(); }
const bar = (v, max, cls = '') => `<div class="bar in ${cls}"><i style="width:${Math.max(0, Math.min(100, v / max * 100))}%"></i></div>`;
function renderStatus() {
  const st = status(), left = S.zeroSince ? Math.max(0, RULES.deathAfter - (now() - S.zeroSince) / HOUR) : 0;
  $('#cBody').innerHTML = `<div class="small"><b>${STATUS_TXT[st]}</b> · ур. ${S.lvl} · ${ageDays()} дн. (рекорд ${S.record || 0})</div>
    ${[['energy', '😴 Энергия'], ['food', '🍔 Сытость'], ['water', '🥤 Вода']].map(([k, n]) => `<div class="lbl">${n} ${Math.round(S[k])}%</div>${bar(S[k], 100, S[k] < RULES.low ? 'low' : '')}`).join('')}
    <div class="lbl">⭐ Опыт ${S.xp}/${xpNeed(S.lvl)}</div>${bar(S.xp, xpNeed(S.lvl), 'xp')}
    ${st === 'faint' ? `<div class="small warn">Выгорит через ${left.toFixed(1)} ч!</div>` : ''}`;
}
function showStatus() { showCard('Статус', ''); renderStatus(); sidePlace(card, -20); syncWindow(); }
function showDead() { showCard('Game over', `<div class="small"><b>Пиксель выгорела</b><br>Прожила ${ageDays()} дн., уровень ${S.lvl}.<br>Рекорд: ${S.record} дн.</div>
    <div class="cbtns"><div class="btn out" data-m="restart">🔄 Начать заново</div></div>`); }
function wardrobe() {
  const bySlot = {}; ITEMS.forEach(i => (bySlot[i.slot] = bySlot[i.slot] || []).push(i));
  openDlg('Гардероб', Object.entries(bySlot).map(([slot, list]) => `<fieldset class="grp"><legend>${SLOTS[slot]}</legend>
    <label class="rb"><input type="radio" name="${slot}" value="" ${!S.eq[slot] ? 'checked' : ''}> Обычное</label>
    ${list.map(i => `<label class="rb ${unlocked(i) ? '' : 'lock'}"><input type="radio" name="${slot}" value="${i.id}" ${S.eq[slot] === i.id ? 'checked' : ''} ${unlocked(i) ? '' : 'disabled'}>
      ${unlocked(i) ? '' : '🔒 '}${i.n}${unlocked(i) ? '' : ` <small>(ур. ${i.lvl})</small>`}</label>`).join('')}</fieldset>`).join('') +
    `<div class="cbtns"><div class="btn out" data-close>Готово</div></div>`);
  $('#dBody').onchange = e => { equip(e.target.name, e.target.value); draw(); say('Как я тебе? 💅', 1600); };
}
function help() {
  openDlg('Правила', `<div class="txt">
    <b>Потребности.</b> Энергия (~4%/ч, ночью вдвое больше), сытость (~6%/ч) и вода (~8%/ч). Ниже 30% — над головой появляется хотелка, нажми на неё.<br><br>
    <b>Прихоти.</b> Перекур, музыка, кофе, танец, прогулка. Исполнишь за час — +${RULES.xpWish} опыта.<br><br>
    <b>Сон.</b> Выспалась до 100% — +${RULES.xpFullSleep} опыта. На зарядке спит быстрее.<br><br>
    <b>Касания.</b> Тап — погладить. Потяни — перенесёшь (не роняй с высоты!). «⋯» — меню.<br><br>
    <b>Телефон.</b> Шаги дают опыт. Она замечает сообщения, музыку, зарядку, тряску, наклон, погоду и интернет.<br><br>
    <b>Хардкор.</b> Если хоть одна потребность на нуле ${RULES.deathAfter} часов — Пиксель выгорает, игра начинается заново.</div>
    <div class="cbtns"><div class="btn out" data-close>Понятно</div></div>`);
}
function openDlg(title, html) { $('#dTitle').textContent = title; $('#dBody').innerHTML = html; dlg.classList.add('show'); syncWindow(); }
function closeDlg() { dlg.classList.remove('show'); syncWindow(); }
dlg.addEventListener('click', e => { if (e.target.closest('[data-close]')) closeDlg(); });
let hideT = null;
function hide(on, minutes) {
  hidden = on; petEl.style.display = on ? 'none' : ''; bubble.classList.remove('show'); closeMenu(); closeCard();
  N('setHidden', on);
  clearTimeout(hideT); if (on && minutes) hideT = setTimeout(() => hide(false), minutes * 60e3 / (NATIVE ? 1 : 240));
  if (!on) { draw(); place(); }
}

/* ================= РЕАКЦИИ НА ТЕЛЕФОН (вызывает Android) ================= */
let screenOnSince = Date.now(), lastEyeRest = Date.now(), lastWater = Date.now(), lastSysSay = 0, POMO = null, NEXT_ALARM = 0, netDown = false, fullscreen = false;
const calm = (ms = 25000) => { if (Date.now() - lastSysSay < ms) return false; lastSysSay = Date.now(); return true; };
const APPKIND = (pkg, cat) => /youtube|kinopoisk|ivi|okko|netflix|twitch|rutube|vk\.video|premier|wink|kion|player|vlc|video/.test(pkg) || cat === 2 ? 'video'
  : /game|supercell|roblox|minecraft|mojang|pubg|genshin|hoyoverse|brawl|clash|standoff|chess/.test(pkg) || cat === 0 ? 'game'
  : /bank|sber|tinkoff|tbank|alfa|vtb|mirpay/.test(pkg) ? 'bank' : /ozon|wildberries|market|beru|avito/.test(pkg) ? 'shop'
  : /telegram|whatsapp|vkontakte|oneme|discord|viber/.test(pkg) ? 'chat' : 'other';
const SYS = {
  /* 1–2 батарея */
  charging(on) { window.CHARGING = on; if (status() === 'awake' && calm(5000)) on ? act('drink', '⚡ Пью электричество… вкусно!') : say('Отключили от розетки'); if (status() === 'sleep' && on) say('*спит на зарядке ещё слаще*', 2000); },
  battery(level) { if (level <= 15 && !window.CHARGING && status() === 'awake' && calm(10 * 60e3)) { spawn('sweat', '💧', PW - 8, 4, 1400); say('Батарея садится! 😰 Где зарядка?!'); goTo(Math.random() * (SCREEN.w - PW), 120); } },
  /* 3–4 уведомления */
  notify(app, unread) {
    if (status() !== 'awake' || hidden || fullscreen) return;
    if (unread >= 15 && calm(30 * 60e3)) { act('wave', `У тебя ${unread} уведомлений. Разгреби уже 😤`); return; }
    if (calm(20000)) act('wave', `Тебе пишут в ${app}! 📩`);
  },
  /* 5 музыка */
  music(title) { if (status() !== 'awake' || hidden) return; act('music', title); },
  /* 6–7 что открыто */
  app(pkg, label, cat) {
    if (status() !== 'awake' || hidden) return;
    const k = APPKIND(pkg || '', +cat);
    if (k === 'video' && calm()) act('watch', pick(['Смотрим вместе 🍿', 'О, кино! Я тихо']));
    else if (k === 'game' && calm()) act('cheer', pick(['Давай, жги! 🎮', 'Я болею за тебя!']));
    else if (k === 'bank' && calm(60e3)) say('Денег нет, но ты держись 💳');
    else if (k === 'shop' && calm(60e3)) say('Корзина не резиновая! 🛒');
  },
  fullscreen(on) { fullscreen = on; if (on && !hidden) { hide(true); SYS._autoHidden = true; } else if (!on && SYS._autoHidden) { SYS._autoHidden = false; hide(false); } },
  /* 8, 16 экран и разблокировка */
  screen(on) { if (on) { screenOnSince = Date.now(); lastEyeRest = Date.now(); } },
  unlock(awayMs) {
    if (status() !== 'awake') return;
    const h = hourNow();
    if (awayMs > 6 * HOUR / (NATIVE ? 1 : 1) && h >= 5 && h < 12) act('wave', pick(T.morning));
    else if (awayMs > 30 * 60e3) act('wave', pick(['С возвращением! 👋', 'О, ты вернулся! Я не скучала. Почти']));
  },
  /* 9–11 датчики */
  shake() { if (status() !== 'awake' || !calm(4000)) return; stopAnim(); LOOK.eyes = 'x'; draw(); spawn('stars', '✦ ✧ ✦', 8, -8, 1400); say('Не тряси! 😵'); later(end, 1600); },
  tilt(x) { if (status() !== 'awake' || mode === 'drag' || Math.abs(x) < 4.5 || !calm(6000)) return; say('Ааа, скольжу! 🛝', 1500); goTo(x > 0 ? 0 : SCREEN.w - PW, 160); },
  wave() { if (status() === 'awake' && calm(4000)) act('wave', 'Привет-привет! 👋'); },
  /* 12 темнота */
  dark(on) { if (on && status() === 'awake' && calm(20 * 60e3)) { const h = hourNow(); say(h >= 21 || h < 6 ? 'Темно… может, спать? 🌙' : 'Темновато тут. Держи фонарик 🔦'); spawn('item', '🔦', HAND().x, HAND().y - 26, 4000); } },
  /* 13 шаги */
  steps(n) {
    const d = new Date(now()).toDateString(); if (EXTRA.stepsDay !== d) { EXTRA.stepsDay = d; EXTRA.stepsXp = 0; EXTRA.acc = 0; }
    EXTRA.acc = (EXTRA.acc || 0) + n;
    while (EXTRA.acc >= 300 && EXTRA.stepsXp < 20) { EXTRA.acc -= 300; EXTRA.stepsXp++; addXp(1, 'шаги'); if (calm(10 * 60e3)) say('Гуляем! 🚶 +опыт'); }
  },
  /* 14 погода */
  weather(t, code) {
    LOOK.hat = t <= -5 ? 'hat_ush' : null;
    const rain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82) || code >= 95;
    const um = $('#umbrella'); if (um) um.remove();
    if (rain) { const d = spawn('umbrella', '☂️', 8, -34, 0); d.id = 'umbrella'; }
    draw();
    if (calm(60e3)) say(t <= -5 ? `Бррр, ${Math.round(t)}°! Надела ушанку 🧣` : rain ? 'Дождь… взяла зонтик ☂️' : t >= 28 ? `Жара ${Math.round(t)}°. Пиксели плавятся` : '');
  },
  /* 15 будильник */
  nextAlarm(ms) { NEXT_ALARM = +ms || 0; },
  /* 17 интернет */
  net(ok) {
    if (!ok && !netDown) { netDown = true; const d = spawn('sign', '404', PW / 2 - 16, -40, 0); d.id = 'sign404'; if (status() === 'awake') say('Интернет пропал… 404 😿'); }
    if (ok && netDown) { netDown = false; const d = $('#sign404'); if (d) d.remove(); if (status() === 'awake') say('Интернет вернулся! 🎉'); }
  },
};
window.SYS = SYS;
/* 8, 15, 18 — проверки по времени */
function sysLoop() {
  const t = Date.now(), h = hourNow(), st = status();
  if (st === 'awake' && !hidden) {
    if (t - lastEyeRest > 60 * 60e3 * (NATIVE ? 1 : 1 / 60)) { lastEyeRest = t; say('Ты уже час в телефоне. Дай глазам отдохнуть 👀', 4000); }
    if (h >= 9 && h < 22 && t - lastWater > 2 * HOUR / CLOCK.speed) { lastWater = t; act('drink', 'Попей воды тоже 💧'); }
  }
  if (NEXT_ALARM && now() >= NEXT_ALARM && now() - NEXT_ALARM < 10 * 60e3) {
    NEXT_ALARM = 0; if (S.asleep) wake(true); setTimeout(() => act('dance'), 500); setTimeout(() => say('Подъём! ⏰ Новый день!'), 700);
  }
}
/* 19 помодоро */
function pomodoro() {
  if (POMO) { clearTimeout(POMO.t); POMO = null; const d = $('#pc'); if (d) d.remove(); say('Помодоро остановлен'); return; }
  const work = 25 * 60e3 / (NATIVE ? 1 : 60), rest = 5 * 60e3 / (NATIVE ? 1 : 60);
  const d = spawn('item', '💻', -22, PH() - 30, 0); d.id = 'pc';
  say('Работаем 25 минут! Я тоже 💻', 3000);
  POMO = { t: setTimeout(() => { N('vibrate', 400); d.textContent = '🍵'; act('dance'); say('Перерыв 5 минут! 🎉', 5000);
    POMO.t = setTimeout(() => { N('vibrate', 400); d.remove(); POMO = null; say('Перерыв окончен. Ещё раунд? 🍅', 4000); }, rest); }, work) };
}

/* 14 — погода раз в час (в приложении) */
async function weatherLoop() {
  if (!NATIVE) return;
  let ll = N('location') || ''; try { if (ll) localStorage.setItem('pixelpet.ll', ll); else ll = localStorage.getItem('pixelpet.ll') || '55.7558,37.6173'; } catch (e) { ll = ll || '55.7558,37.6173'; }
  const [lat, lon] = ll.split(',');
  try { const r = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code&timezone=auto`);
    const j = await r.json(); SYS.weather(j.current.temperature_2m, j.current.weather_code); } catch (e) {}
}
setTimeout(weatherLoop, 5000); setInterval(weatherLoop, 60 * 60e3);

/* ---------- старт ---------- */
window.onNative = () => { readScreen(); place(); };        // Android сообщает об изменении экрана
window.addEventListener('resize', () => { if (!NATIVE) { readScreen(); POS.y = Math.min(POS.y, floorY()); place(); } });
readScreen(); initPos(); draw(); lastStatus = status(); lastWant = (w => w ? w.kind + w.id : null)(topWant());
setInterval(loop, 1000);
setTimeout(() => { const h = hourNow(); say(pick(h >= 5 && h < 11 ? T.morning : (h >= 23 || h < 5) ? T.night : T.hello), 3000); }, 800);
