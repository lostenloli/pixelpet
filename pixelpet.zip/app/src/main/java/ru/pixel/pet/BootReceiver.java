package ru.pixel.pet;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

/** После перезагрузки телефона (или обновления приложения) Пиксель возвращается сама. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (PetService.prefs(c).getBoolean("enabled", false) && Settings.canDrawOverlays(c)) {
            try { PetService.start(c); } catch (Exception ignored) {}
        }
    }
}
