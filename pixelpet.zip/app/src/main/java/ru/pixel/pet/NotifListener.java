package ru.pixel.pet;

import android.app.Notification;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONObject;

/** Уведомления: Пиксель машет и говорит, из какого приложения пришло сообщение. Нужен доступ к уведомлениям. */
public class NotifListener extends NotificationListenerService {

    static boolean enabled(Context c) {
        String flat = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(new ComponentName(c, NotifListener.class).flattenToString());
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn.getPackageName().equals(getPackageName()) || sbn.isOngoing()) return;
            Notification n = sbn.getNotification();
            if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
            if (n.extras.getCharSequence(Notification.EXTRA_TITLE) == null && n.extras.getCharSequence(Notification.EXTRA_TEXT) == null) return;
            PackageManager pm = getPackageManager();
            String label = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(sbn.getPackageName(), 0)));
            int count = 0;
            StatusBarNotification[] all = getActiveNotifications();
            if (all != null) for (StatusBarNotification s : all) if (s.isClearable() && (s.getNotification().flags & Notification.FLAG_GROUP_SUMMARY) == 0) count++;
            PetService.jsStatic("SYS.notify(" + JSONObject.quote(label) + "," + count + ")");
        } catch (Exception ignored) {}
    }
}
