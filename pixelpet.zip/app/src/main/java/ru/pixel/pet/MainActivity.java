package ru.pixel.pet;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AppOpsManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.Process;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

/** Экран настройки: разрешения, высота «пола», запуск и остановка Пикселя. */
public class MainActivity extends Activity {

    private WebView web;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Api(), "Setup");
        setContentView(web);
        web.loadUrl("file:///android_asset/setup.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.evaluateJavascript("window.refresh && refresh()", null);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (web != null) web.evaluateJavascript("window.refresh && refresh()", null);
    }

    private boolean perm(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    private void go(Intent i) {
        runOnUiThread(() -> {
            try { startActivity(i); }
            catch (Exception e) {
                try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) {}
            }
        });
    }

    class Api {
        @JavascriptInterface public String status() {
            JSONObject o = new JSONObject();
            try {
                o.put("overlay", Settings.canDrawOverlays(MainActivity.this));
                o.put("post", Build.VERSION.SDK_INT < 33 || perm("android.permission.POST_NOTIFICATIONS"));
                o.put("notif", NotifListener.enabled(MainActivity.this));
                AppOpsManager ops = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
                int mode = Build.VERSION.SDK_INT >= 29
                        ? ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName())
                        : ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
                o.put("usage", mode == AppOpsManager.MODE_ALLOWED);
                o.put("steps", Build.VERSION.SDK_INT < 29 || perm("android.permission.ACTIVITY_RECOGNITION"));
                o.put("loc", perm("android.permission.ACCESS_COARSE_LOCATION"));
                o.put("battery", ((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName()));
                o.put("running", PetService.inst != null);
                o.put("floor", PetService.prefs(MainActivity.this).getInt("floor", 150));
            } catch (Exception ignored) {}
            return o.toString();
        }

        @SuppressLint("BatteryLife")
        @JavascriptInterface public void ask(String what) {
            Uri pkg = Uri.parse("package:" + getPackageName());
            switch (what) {
                case "overlay": go(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)); break;
                case "notif": go(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); break;
                case "usage": go(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); break;
                case "battery": go(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg)); break;
                case "app": go(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)); break;
                case "post": if (Build.VERSION.SDK_INT >= 33) runOnUiThread(() -> requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1)); break;
                case "steps": if (Build.VERSION.SDK_INT >= 29) runOnUiThread(() -> requestPermissions(new String[]{"android.permission.ACTIVITY_RECOGNITION"}, 2)); break;
                case "loc": runOnUiThread(() -> requestPermissions(new String[]{"android.permission.ACCESS_COARSE_LOCATION"}, 3)); break;
            }
        }

        @JavascriptInterface public boolean start() {
            if (!Settings.canDrawOverlays(MainActivity.this)) return false;
            PetService.prefs(MainActivity.this).edit().putBoolean("enabled", true).apply();
            if (PetService.inst == null) PetService.start(MainActivity.this);
            return true;
        }

        @JavascriptInterface public void stop() {
            PetService.prefs(MainActivity.this).edit().putBoolean("enabled", false).apply();
            stopService(new Intent(MainActivity.this, PetService.class));
        }

        @JavascriptInterface public void setFloor(int dp) {
            PetService.prefs(MainActivity.this).edit().putInt("floor", dp).apply();
            PetService.jsStatic("window.onNative && onNative()");
        }

        @JavascriptInterface public void restart() {
            // перезапуск службы, чтобы подхватить новые разрешения (шаги, датчики)
            stopService(new Intent(MainActivity.this, PetService.class));
            if (PetService.prefs(MainActivity.this).getBoolean("enabled", false))
                web.postDelayed(() -> PetService.start(MainActivity.this), 800);
        }
    }
}
