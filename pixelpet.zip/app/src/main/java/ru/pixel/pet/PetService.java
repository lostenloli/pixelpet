package ru.pixel.pet;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.location.Location;
import android.location.LocationManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.WindowMetrics;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.List;

/**
 * Пиксель живёт здесь: маленькое прозрачное окно поверх всех приложений (WebView с pet.html),
 * которое ездит за ней по экрану. Служба слушает батарею, экран, датчики, сеть, музыку и
 * открытые приложения и сообщает об этом в JS (window.SYS.*).
 */
public class PetService extends Service implements SensorEventListener {

    static volatile PetService inst;
    static final String PREFS = "pet";

    private WindowManager wm;
    private WebView web;
    private WindowManager.LayoutParams lp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean ready = false, screenOn = true;
    private float dens = 1f;
    private SensorManager sm;
    private long lastShakeT = 0, lastTiltT = 0, tiltSince = 0, proxNearT = 0, screenOffAt = 0;
    private boolean proxNear = false, dark = false;
    private float tiltX = 0;
    private int lastSteps = -1;
    private String lastFg = "", lastTrack = "";
    private int lastLevel = -1;
    private boolean lastCharging = false;
    private ConnectivityManager.NetworkCallback netCb;
    private String torchId;

    // ------------------------------------------------------------------ запуск

    static void start(Context c) {
        Intent i = new Intent(c, PetService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, MODE_PRIVATE); }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        startFg();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        dens = getResources().getDisplayMetrics().density;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createOverlay();
        registerAll();
        findTorch();
        h.postDelayed(poll, 4000);
    }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("pet", "Пиксель на экране", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "pet") : new Notification.Builder(this);
        Notification n = b.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Пиксель живёт на экране")
                .setContentText("Нажмите, чтобы открыть настройки")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void createOverlay() {
        web = new WebView(this);
        web.setBackgroundColor(0x00000000);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        web.addJavascriptInterface(new Api(), "PetNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                ready = true;
                sendInitial();
            }
        });

        lp = new WindowManager.LayoutParams(dp(120), dp(200),
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        Rect sc = screenPx();
        lp.x = sc.width() - dp(140);
        lp.y = sc.height() - dp(400);
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(web, lp);
        web.loadUrl("file:///android_asset/pet.html");
    }

    private int dp(float v) { return Math.round(v * dens); }

    private Rect screenPx() {
        if (Build.VERSION.SDK_INT >= 30) return wm.getCurrentWindowMetrics().getBounds();
        DisplayMetrics m = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(m);
        return new Rect(0, 0, m.widthPixels, m.heightPixels);
    }

    private int[] insetsPx() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowMetrics wmx = wm.getCurrentWindowMetrics();
            android.graphics.Insets in = wmx.getWindowInsets().getInsetsIgnoringVisibility(WindowInsets.Type.systemBars());
            return new int[]{in.top, in.bottom};
        }
        int top = 0, bottom = 0;
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (id > 0) top = getResources().getDimensionPixelSize(id);
        id = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
        if (id > 0) bottom = getResources().getDimensionPixelSize(id);
        return new int[]{top, bottom};
    }

    void js(String code) {
        h.post(() -> { if (web != null && ready) web.evaluateJavascript(code, null); });
    }

    static void jsStatic(String code) { PetService s = inst; if (s != null) s.js(code); }

    private void sendInitial() {
        try {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            AlarmManager.AlarmClockInfo a = am.getNextAlarmClock();
            if (a != null) js("SYS.nextAlarm(" + a.getTriggerTime() + ")");
        } catch (Exception ignored) {}
        js("window.onNative && onNative()");
        if (lastCharging) js("SYS.charging(true)");
    }

    // ------------------------------------------------------------------ мост для JS

    class Api {
        @JavascriptInterface public String screen() {
            Rect r = screenPx();
            int[] in = insetsPx();
            JSONObject o = new JSONObject();
            try {
                o.put("w", Math.round(r.width() / dens));
                o.put("h", Math.round(r.height() / dens));
                o.put("top", Math.round(in[0] / dens));
                o.put("bottom", Math.round(in[1] / dens));
            } catch (Exception ignored) {}
            return o.toString();
        }

        @JavascriptInterface public int floor() { return prefs(PetService.this).getInt("floor", 150); }

        @JavascriptInterface public void setWindow(int x, int y, int w, int hh) {
            h.post(() -> {
                if (web == null || lp == null) return;
                lp.x = dp(x); lp.y = dp(y); lp.width = Math.max(1, dp(w)); lp.height = Math.max(1, dp(hh));
                try { wm.updateViewLayout(web, lp); } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public void setHidden(boolean hidden) {
            h.post(() -> {
                if (web == null) return;
                web.setVisibility(hidden ? View.INVISIBLE : View.VISIBLE);
                if (hidden) lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                else lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                try { wm.updateViewLayout(web, lp); } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v != null) v.vibrate(VibrationEffect.createOneShot(Math.max(1, ms), VibrationEffect.DEFAULT_AMPLITUDE));
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public boolean torch(boolean on) {
            if (torchId == null) return false;
            try { ((CameraManager) getSystemService(CAMERA_SERVICE)).setTorchMode(torchId, on); return true; }
            catch (Exception e) { return false; }
        }

        @JavascriptInterface public void open(String what) {
            Intent i;
            switch (what) {
                case "alarm": i = new Intent(AlarmClock.ACTION_SHOW_ALARMS); break;
                case "camera": i = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA); break;
                default: i = new Intent(PetService.this, MainActivity.class);
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { startActivity(i); } catch (Exception ignored) {}
        }

        @JavascriptInterface public String location() {
            if (checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return "";
            try {
                LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
                Location best = null;
                for (String p : new String[]{LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER, LocationManager.GPS_PROVIDER}) {
                    try {
                        Location l = lm.getLastKnownLocation(p);
                        if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                    } catch (Exception ignored) {}
                }
                return best == null ? "" : best.getLatitude() + "," + best.getLongitude();
            } catch (Exception e) { return ""; }
        }
    }

    private void findTorch() {
        try {
            CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                Boolean f = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (f != null && f && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) { torchId = id; break; }
            }
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------------ события системы

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (a == null) return;
            switch (a) {
                case Intent.ACTION_BATTERY_CHANGED: {
                    int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                    int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                    boolean ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
                    int pct = scale > 0 ? Math.round(level * 100f / scale) : level;
                    if (ch != lastCharging && lastLevel >= 0) js("SYS.charging(" + ch + ")");
                    if (pct != lastLevel) js("SYS.battery(" + pct + ")");
                    lastCharging = ch; lastLevel = pct;
                    break;
                }
                case Intent.ACTION_SCREEN_OFF:
                    screenOn = false; screenOffAt = System.currentTimeMillis();
                    js("SYS.screen(false)");
                    stopSensors();
                    h.postDelayed(() -> { if (!screenOn && web != null) { web.onPause(); web.pauseTimers(); } }, 500);
                    break;
                case Intent.ACTION_SCREEN_ON:
                    screenOn = true;
                    if (web != null) { web.onResume(); web.resumeTimers(); }
                    js("SYS.screen(true)");
                    startSensors();
                    break;
                case Intent.ACTION_USER_PRESENT:
                    js("SYS.unlock(" + (screenOffAt > 0 ? System.currentTimeMillis() - screenOffAt : 0) + ")");
                    break;
            }
        }
    };

    private void registerAll() {
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_BATTERY_CHANGED);
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_USER_PRESENT);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_EXPORTED); else registerReceiver(rx, f);

        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network n) { js("SYS.net(true)"); }
                @Override public void onLost(Network n) { js("SYS.net(false)"); }
            };
            cm.registerDefaultNetworkCallback(netCb);
        } catch (Exception ignored) {}

        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        startSensors();
        Sensor steps = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        boolean stepPerm = Build.VERSION.SDK_INT < 29 || checkSelfPermission(android.Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED;
        if (steps != null && stepPerm) sm.registerListener(this, steps, SensorManager.SENSOR_DELAY_NORMAL, 5 * 60 * 1000 * 1000);
    }

    private void startSensors() {
        if (sm == null) return;
        Sensor acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensor prox = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        Sensor light = sm.getDefaultSensor(Sensor.TYPE_LIGHT);
        if (acc != null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_UI);
        if (prox != null) sm.registerListener(this, prox, SensorManager.SENSOR_DELAY_NORMAL);
        if (light != null) sm.registerListener(this, light, SensorManager.SENSOR_DELAY_NORMAL);
    }

    private void stopSensors() {
        if (sm == null) return;
        for (int t : new int[]{Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_PROXIMITY, Sensor.TYPE_LIGHT}) {
            Sensor s = sm.getDefaultSensor(t);
            if (s != null) sm.unregisterListener(this, s);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        long t = System.currentTimeMillis();
        switch (e.sensor.getType()) {
            case Sensor.TYPE_ACCELEROMETER: {
                float x = e.values[0], y = e.values[1], z = e.values[2];
                double g = Math.sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH;
                if (g > 2.6 && t - lastShakeT > 1500) { lastShakeT = t; js("SYS.shake()"); }
                // наклон: держим телефон вертикально и наклоняем вбок
                if (Math.abs(x) > 5 && Math.abs(z) < 7) {
                    if (tiltSince == 0 || Math.signum(x) != Math.signum(tiltX)) { tiltSince = t; tiltX = x; }
                    else if (t - tiltSince > 900 && t - lastTiltT > 6000) { lastTiltT = t; js("SYS.tilt(" + x + ")"); }
                } else tiltSince = 0;
                break;
            }
            case Sensor.TYPE_PROXIMITY: {
                boolean near = e.values[0] < Math.min(3f, e.sensor.getMaximumRange());
                if (near && !proxNear) proxNearT = t;
                if (!near && proxNear && t - proxNearT < 1200) js("SYS.wave()");
                proxNear = near;
                break;
            }
            case Sensor.TYPE_LIGHT: {
                boolean d = e.values[0] < 3f;
                if (d != dark) { dark = d; js("SYS.dark(" + d + ")"); }
                break;
            }
            case Sensor.TYPE_STEP_COUNTER: {
                int total = Math.round(e.values[0]);
                if (lastSteps >= 0 && total > lastSteps) js("SYS.steps(" + (total - lastSteps) + ")");
                lastSteps = total;
                break;
            }
        }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        js("SYS.fullscreen(" + (c.orientation == Configuration.ORIENTATION_LANDSCAPE) + ")");
        js("window.onNative && onNative()");
    }

    // ------------------------------------------------------------------ опрос: что открыто, что играет

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (screenOn) {
                checkForeground();
                checkMusic();
            }
            h.postDelayed(this, 4000);
        }
    };

    private boolean hasUsage() {
        try {
            AppOpsManager ops = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = Build.VERSION.SDK_INT >= 29
                    ? ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName())
                    : ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }

    @SuppressWarnings("deprecation")
    private void checkForeground() {
        if (!hasUsage()) return;
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            UsageEvents ev = usm.queryEvents(now - 10000, now);
            UsageEvents.Event e = new UsageEvents.Event();
            String pkg = null;
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) pkg = e.getPackageName();
            }
            if (pkg == null || pkg.equals(lastFg) || pkg.equals(getPackageName())) return;
            lastFg = pkg;
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            String label = String.valueOf(pm.getApplicationLabel(ai));
            int cat = Build.VERSION.SDK_INT >= 26 ? ai.category : -1;
            js("SYS.app(" + JSONObject.quote(pkg) + "," + JSONObject.quote(label) + "," + cat + ")");
        } catch (Exception ignored) {}
    }

    private void checkMusic() {
        if (!NotifListener.enabled(this)) return;
        try {
            MediaSessionManager msm = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
            List<MediaController> list = msm.getActiveSessions(new ComponentName(this, NotifListener.class));
            String track = "";
            for (MediaController c : list) {
                PlaybackState ps = c.getPlaybackState();
                MediaMetadata md = c.getMetadata();
                if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING && md != null) {
                    String title = md.getString(MediaMetadata.METADATA_KEY_TITLE);
                    String artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST);
                    if (title != null) { track = artist != null ? artist + " — " + title : title; break; }
                }
            }
            if (!track.isEmpty() && !track.equals(lastTrack)) js("SYS.music(" + JSONObject.quote(track) + ")");
            lastTrack = track;
        } catch (Exception ignored) {}
    }

    @Override
    public void onDestroy() {
        inst = null;
        h.removeCallbacksAndMessages(null);
        try { unregisterReceiver(rx); } catch (Exception ignored) {}
        try { if (netCb != null) ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).unregisterNetworkCallback(netCb); } catch (Exception ignored) {}
        try { if (sm != null) sm.unregisterListener(this); } catch (Exception ignored) {}
        try { if (web != null) { wm.removeView(web); web.destroy(); } } catch (Exception ignored) {}
        web = null;
        super.onDestroy();
    }
}
